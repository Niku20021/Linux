<?php
$conn = new mysqli("localhost", "root", "", "proiectbd");
if ($conn->connect_error) {
    die("Eroare conexiune: " . $conn->connect_error);
}

if (isset($_GET['sterge'])) {
    $id = (int)$_GET['sterge'];
    $conn->query("CALL returneaza_comanda($id)");
    header("Location: afiseaza_comenzi.php");
    exit;
}

$sql = "SELECT c.id_comanda, comp.nume AS componenta, f.nume_furnizor AS furnizor,
               c.cantitate, c.pret_unitar, c.tva, c.pret_total, c.data_comanda
        FROM comenzi c
        JOIN componente comp ON c.id_componente = comp.id_componente
        JOIN furnizori f ON c.id_furnizor = f.id_furnizor";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Vezi Comenzi</title>
    <link rel="stylesheet" href="style6.css">
</head>
<body>

<header>
    <div class="container">
        <h1>Gestionare Componente</h1>
        <nav>
            <ul>
                <li><a href="index.php">Pagina Principală</a></li>
                <li><a href="adauga_componente.php">Adaugă Componentă</a></li>
                <li><a href="afiseaza_componente.php">Vezi Componente</a></li>
                <li><a href="adauga_asociere.php">Asociază Componență</a></li>
                <li><a href="adauga_comenzi.php">Adaugă Comandă</a></li>
                <li><a href="afiseaza_comenzi.php" class="active">Vezi Comenzi</a></li>
            </ul>
        </nav>
    </div>
</header>

<main>
    <div class="container">
        <h2>📋 Comenzi Înregistrate</h2>

        <div class="table-card">
            <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                <tr>
                    <th>#</th>
                    <th>🔧 Componentă</th>
                    <th>🏭 Furnizor</th>
                    <th>📦 Cantitate</th>
                    <th>💰 Preț</th>
                    <th>🧾 TVA</th>
                    <th>💸 Total</th>
                    <th>📅 Dată</th>
                    <th>🗑️ Acțiuni</th>
                </tr>
                </thead>
                <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['id_comanda'] ?></td>
                        <td><?= htmlspecialchars($row['componenta']) ?></td>
                        <td><?= htmlspecialchars($row['furnizor']) ?></td>
                        <td><?= $row['cantitate'] ?></td>
                        <td><?= number_format($row['pret_unitar'], 2) ?> lei</td>
                        <td><?= $row['tva'] ?>%</td>
                        <td><?= number_format($row['pret_total'], 2) ?> lei</td>
                        <td><?= $row['data_comanda'] ?></td>
                        <td>
                            <a href="?sterge=<?= $row['id_comanda'] ?>" class="btn delete" onclick="return confirm('Ești sigur că vrei să returnezi această comandă?')">Returnează</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
                <p style="text-align:center; font-weight: bold;">Nu există comenzi înregistrate.</p>
            <?php endif; ?>
        </div>
    </div>
</main>

<footer>
    <div class="container">
        <p>&copy; 2025 Gestionare Componente. Toate drepturile rezervate.</p>
    </div>
</footer>

</body>
</html>
