<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "proiectbd";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexiunea a eșuat: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nume = $_POST["nume"];
    $categorie = $_POST["categorie"];
    $cantitate = $_POST["cantitate"];

    $stmt = $conn->prepare("INSERT INTO componente (nume, categorie, cantitate) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $nume, $categorie, $cantitate);
    $stmt->execute();

    echo "<script>alert('Componentă adăugată cu succes!'); window.location='adauga_componente.php';</script>";
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Adaugă Componentă</title>
    <link rel="stylesheet" href="style6.css">
</head>
<body>

<header>
    <div class="container">
        <h1>Gestionare Componente</h1>
        <nav>
            <ul>
                <li><a href="index.php">Pagina Principală</a></li>
                <li><a href="adauga_componente.php" class="active">Adaugă Componentă</a></li>
                <li><a href="afiseaza_componente.php">Vezi Componente</a></li>
                <li><a href="adauga_asociere.php">Asociază Componență</a></li>
                <li><a href="adauga_comenzi.php">Adaugă Comandă</a></li>
                <li><a href="afiseaza_comenzi.php">Vezi Comenzi</a></li>
            </ul>
        </nav>
    </div>
</header>

<main>
    <div class="form-card">
        <h2>Adaugă Componentă Nouă</h2>

        <form method="POST" action="adauga_componente.php">
            <div class="form-group">
                <label for="nume">Nume Componentă:</label>
                <input type="text" name="nume" id="nume" required>
            </div>

            <div class="form-group">
                <label for="categorie">Categorie:</label>
                <input type="text" name="categorie" id="categorie" required>
            </div>

            <div class="form-group">
                <label for="cantitate">Cantitate:</label>
                <input type="number" name="cantitate" id="cantitate" min="1" required>
            </div>

            <button type="submit" class="btn">Adaugă Componenta</button>
        </form>
    </div>
</main>

<footer>
    <div class="container">
        <p>&copy; 2025 Gestionare Componente. Toate drepturile rezervate.</p>
    </div>
</footer>

</body>
</html>
