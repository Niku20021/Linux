<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "proiectbd";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexiunea a eșuat: " . $conn->connect_error);
}

// Preluăm componente și furnizori
$componente = $conn->query("SELECT id_componente, nume FROM componente");
$furnizori = $conn->query("SELECT id_furnizor, nume_furnizor FROM furnizori");

// Inserăm comanda dacă s-a trimis formularul
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_componente = $_POST["componenta"];
    $id_furnizor = $_POST["furnizor"];
    $cantitate = $_POST["cantitate"];
    $pret_unitar = $_POST["pret_unitar"];
    $tva = $_POST["tva"];
    $data = $_POST["data"];

    $pret_total = $cantitate * $pret_unitar * (1 + $tva / 100);

    $stmt = $conn->prepare("INSERT INTO comenzi 
        (id_componente, id_furnizor, cantitate, pret_unitar, tva, pret_total, data_comanda)
        VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iiiddds", $id_componente, $id_furnizor, $cantitate, $pret_unitar, $tva, $pret_total, $data);
    $stmt->execute();

    echo "<script>alert('Comanda a fost adăugată cu succes!'); window.location='adauga_comenzi.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Adaugă Comandă</title>
    <link rel="stylesheet" href="style6.css">
</head>
<body>

<header>
    <h1>Gestionare Componente</h1>
    <nav>
        <ul>
            <li><a href="index.php">Pagina Principală</a></li>
            <li><a href="adauga_componente.php">Adaugă Componentă</a></li>
            <li><a href="afiseaza_componente.php">Vezi Componente</a></li>
            <li><a href="adauga_asociere.php">Asociază Componentă</a></li>
            <li><a href="adauga_comenzi.php">Adaugă Comandă</a></li>
			<li><a href="afiseaza_comenzi.php">Vezi Comenzi</a></li>
        </ul>
    </nav>
</header>

<main>
    <div class="form-card">
        <h2>Adaugă o Comandă</h2>
        <form method="POST" action="adauga_comenzi.php">

            <div class="form-group">
                <label for="componenta">Componentă:</label>
                <select name="componenta" id="componenta" required>
                    <option value="" disabled selected>Alege componenta</option>
                    <?php while($row = $componente->fetch_assoc()): ?>
                        <option value="<?= $row['id_componente'] ?>"><?= htmlspecialchars($row['nume']) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="furnizor">Furnizor:</label>
                <select name="furnizor" id="furnizor" required>
                    <option value="" disabled selected>Alege furnizorul</option>
                    <?php while($row = $furnizori->fetch_assoc()): ?>
                        <option value="<?= $row['id_furnizor'] ?>"><?= htmlspecialchars($row['nume_furnizor']) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="cantitate">Cantitate:</label>
                <input type="number" name="cantitate" id="cantitate" required>
            </div>

            <div class="form-group">
                <label for="pret_unitar">Preț Unitar (lei):</label>
                <input type="number" step="0.01" name="pret_unitar" id="pret_unitar" required>
            </div>

            <div class="form-group">
                <label for="tva">TVA (%):</label>
                <input type="number" name="tva" id="tva" step="0.01" required>
            </div>

            <div class="form-group">
                <label for="data">Data Comenzii:</label>
                <input type="date" name="data" id="data" required>
            </div>

            <button type="submit" class="btn">Adaugă Comandă</button>
        </form>
    </div>
</main>

<footer>
    <p>&copy; 2025 Gestionare Componente. Toate drepturile rezervate.</p>
</footer>

</body>
</html>
