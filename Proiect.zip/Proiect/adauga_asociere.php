<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "proiectbd";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexiunea a eșuat: " . $conn->connect_error);
}

// Preluăm componentele și comenzile
$componente = $conn->query("SELECT id_componente, nume FROM componente");
$comenzi = $conn->query("SELECT id_comanda, descriere FROM comenzi");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_comanda = $_POST["id_comanda"];
    $id_componente = $_POST["id_componente"];

    $stmt = $conn->prepare("INSERT INTO comanda_componente (id_comanda, id_componente) VALUES (?, ?)");
    $stmt->bind_param("ii", $id_comanda, $id_componente);
    $stmt->execute();

    echo "<script>alert('Asociere realizată cu succes!'); window.location='adauga_asociere.php';</script>";
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Asociază Componentă</title>
    <link rel="stylesheet" href="style6.css">
</head>
<body>

<header>
    <div class="container">
        <h1>Gestionare Componente</h1>
        <nav>
            <ul>
                <li><a href="index.php">Pagina Principală</a></li>
                <li><a href="adauga_componente.php">Adaugă Componentă</a></li>
                <li><a href="afiseaza_componente.php">Vezi Componente</a></li>
                <li><a href="adauga_asociere.php" class="active">Asociază Componență</a></li>
                <li><a href="adauga_comenzi.php">Adaugă Comandă</a></li>
                <li><a href="afiseaza_comenzi.php">Vezi Comenzi</a></li>
            </ul>
        </nav>
    </div>
</header>

<main>
    <div class="form-card">
        <h2>Asociază Componentă la Comandă</h2>
        <form method="POST" action="adauga_asociere.php">
            <div class="form-group">
                <label for="id_comanda">Selectează Comanda:</label>
                <select name="id_comanda" id="id_comanda" required>
                    <option value="" disabled selected>Alege o comandă</option>
                    <?php while($row = $comenzi->fetch_assoc()): ?>
                        <option value="<?= $row['id_comanda'] ?>"><?= htmlspecialchars($row['descriere']) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="id_componente">Selectează Componenta:</label>
                <select name="id_componente" id="id_componente" required>
                    <option value="" disabled selected>Alege o componentă</option>
                    <?php while($row = $componente->fetch_assoc()): ?>
                        <option value="<?= $row['id_componente'] ?>"><?= htmlspecialchars($row['nume']) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <button type="submit" class="btn">Asociază</button>
        </form>
    </div>
</main>

<footer>
    <div class="container">
        <p>&copy; 2025 Gestionare Componente. Toate drepturile rezervate.</p>
    </div>
</footer>

</body>
</html>
