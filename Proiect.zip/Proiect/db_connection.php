<?php
// Detalii de conectare la baza de date
$servername = "localhost";
$username = "root";  // Numele de utilizator pentru MySQL
$password = "";  // Parola (lăsată goală pentru XAMPP)
$dbname = "proiectbd";  // Numele bazei de date

// Crează conexiunea
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifică conexiunea
if ($conn->connect_error) {
    $status = "Eroare de conexiune: " . $conn->connect_error;
    $statusClass = "error";  // Clasa pentru stilizarea mesajului de eroare
} else {
    $status = "Conexiune realizată cu succes!";
    $statusClass = "success";  // Clasa pentru stilizarea mesajului de succes
}
?>



<?php
// Închide conexiunea

?>
