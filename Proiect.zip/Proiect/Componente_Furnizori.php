<?php
// Include fișierul de conexiune la baza de date
include 'db_connection.php';

// Mesaje de succes sau eroare
$message = '';
$messageClass = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_componente = $_POST['id_componente'];
    $id_furnizor = $_POST['id_furnizor'];

    // Interogare pentru a adăuga asocierea
    $sql = "INSERT INTO Componente_Furnizori (id_componente, id_furnizor) VALUES ('$id_componente', '$id_furnizor')";

    if ($conn->query($sql) === TRUE) {
        $message = "Componentă asociată cu furnizorul!";
        $messageClass = "success";
    } else {
        $message = "Eroare: " . $conn->error;
        $messageClass = "error";
    }
}

// Preluarea tuturor componentelor și furnizorilor
$componente_sql = "SELECT id_componente, nume FROM Componente";
$componente_result = $conn->query($componente_sql);

$furnizori_sql = "SELECT id_furnizor, nume_furnizor FROM Furnizori";
$furnizori_result = $conn->query($furnizori_sql);

// Preluarea tuturor asocierilor între componente și furnizori
$asocieri_sql = "SELECT c.nume, f.nume_furnizor FROM Componente_Furnizori cf 
                 JOIN Componente c ON cf.id_componente = c.id_componente
                 JOIN Furnizori f ON cf.id_furnizor = f.id_furnizor";
$asocieri_result = $conn->query($asocieri_sql);
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asociază Componentă cu Furnizor</title>
    <link rel="stylesheet" href="style6.css"> <!-- Fișierul CSS pentru stilizare -->
</head>
<body>

    <header>
        <div class="container">
            <h1>Gestionare Componente</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Pagina Principală</a></li>
                    <li><a href="adauga_componente.php">Adaugă Componentă</a></li>
                    <li><a href="afiseaza_componente.php">Vezi Componente</a></li>
                    <li><a href="adauga_asociere.php">Asociază Componentă</a></li>
                    <li><a href="adauga_comenzi.php">Adaugă Comandă</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="content">
        <div class="container">
            <h2>Asociază Componentă cu Furnizor</h2>

            <!-- Afișează mesajul de succes sau eroare -->
            <?php if ($message != ''): ?>
                <div class="status-message <?php echo $messageClass; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- Formular pentru asocierea componentelor cu furnizorii -->
            <form action="adauga_asociere.php" method="POST">
                <label for="id_componente">Componentă:</label><br>
                <select id="id_componente" name="id_componente" required>
                    <?php while($row = $componente_result->fetch_assoc()): ?>
                        <option value="<?php echo $row['id_componente']; ?>"><?php echo $row['nume']; ?></option>
                    <?php endwhile; ?>
                </select><br><br>

                <label for="id_furnizor">Furnizor:</label><br>
                <select id="id_furnizor" name="id_furnizor" required>
                    <?php while($row = $furnizori_result->fetch_assoc()): ?>
                        <option value="<?php echo $row['id_furnizor']; ?>"><?php echo $row['nume_furnizor']; ?></option>
                    <?php endwhile; ?>
                </select><br><br>

                <input type="submit" value="Asociază Componentă cu Furnizor">
            </form>

            <h3>Asocieri Existente</h3>
            <?php if ($asocieri_result->num_rows > 0): ?>
                <table>
                    <tr>
                        <th>Componentă</th>
                        <th>Furnizor</th>
                    </tr>
                    <?php while($row = $asocieri_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['nume']; ?></td>
                            <td><?php echo $row['nume_furnizor']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </table>
            <?php else: ?>
                <p>Nu există asocieri între componente și furnizori.</p>
            <?php endif; ?>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2025 Gestionare Componente</p>
        </div>
    </footer>

</body>
</html>

<?php
$conn->close();
?>
