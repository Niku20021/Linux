<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "proiectbd";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexiunea a eșuat: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionare Componente</title>
    <link rel="stylesheet" href="style6.css">
</head>
<body>

<header>
    <div class="container">
        <h1>Gestionare Componente</h1>
        <nav>
            <ul>
                <li><a href="index.php">Pagina Principală</a></li>
                <li><a href="adauga_componente.php">Adaugă Componentă</a></li>
                <li><a href="afiseaza_componente.php">Vezi Componente</a></li>
                <li><a href="adauga_asociere.php">Asociază Componență</a></li>
                <li><a href="adauga_comenzi.php">Adaugă Comandă</a></li>
                <li><a href="afiseaza_comenzi.php">Vezi Comenzi</a></li>
            </ul>
        </nav>
    </div>
</header>

<main>
    <section class="content">
        <div class="container">
            <!-- Bara de căutare -->
            <div class="search-bar">
                <input type="text" id="searchInput" placeholder="Caută componente...">
            </div>

            <h2>Componente Existente</h2>
            <ul class="componente-list" id="componenteList">
                <!-- Inițial goale, vor fi încărcate cu JavaScript -->
            </ul>
        </div>
    </section>
</main>

<footer>
    <div class="container">
        <p>&copy; 2025 Gestionare Componente. Toate drepturile rezervate.</p>
    </div>
</footer>

<script>
    const searchInput = document.getElementById("searchInput");
    const componenteList = document.getElementById("componenteList");

    function loadComponente(query = "") {
        fetch("cauta_componente.php?q=" + encodeURIComponent(query))
            .then(res => res.text())
            .then(html => {
                componenteList.innerHTML = html;
            });
    }

    searchInput.addEventListener("input", () => {
        const query = searchInput.value.trim();
        loadComponente(query);
    });

    // Încarcă lista inițială
    loadComponente();
</script>

</body>
</html>

