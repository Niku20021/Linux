<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "proiectbd";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexiune eșuată: " . $conn->connect_error);
}

if (!isset($_GET['id'])) {
    die("ID componentă lipsă.");
}

$id = (int)$_GET['id'];

// Salvare modificări
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nume = $_POST["nume"];
    $categorie = $_POST["categorie"];
    $cantitate = $_POST["cantitate"];

    $stmt = $conn->prepare("UPDATE componente SET nume=?, categorie=?, cantitate=? WHERE id_componente=?");
    $stmt->bind_param("ssii", $nume, $categorie, $cantitate, $id);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Componenta a fost actualizată cu succes!'); window.location='afiseaza_componente.php';</script>";
    exit;
}

// Preluare date componentă curentă
$result = $conn->query("SELECT * FROM componente WHERE id_componente = $id");
if ($result->num_rows === 0) {
    die("Componenta nu a fost găsită.");
}
$componenta = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Editează Componentă</title>
    <link rel="stylesheet" href="style6.css">
</head>
<body>
<header>
    <h1>Gestionare Componente</h1>
</header>

<main>
    <div class="form-card">
        <h2>Editează Componentă</h2>
        <form method="POST">
            <div class="form-group">
                <label for="nume">Nume:</label>
                <input type="text" name="nume" id="nume" value="<?= htmlspecialchars($componenta['nume']) ?>" required>
            </div>

            <div class="form-group">
                <label for="categorie">Categorie:</label>
                <input type="text" name="categorie" id="categorie" value="<?= htmlspecialchars($componenta['categorie']) ?>" required>
            </div>

            <div class="form-group">
                <label for="cantitate">Cantitate:</label>
                <input type="number" name="cantitate" id="cantitate" value="<?= $componenta['cantitate'] ?>" min="0" required>
            </div>

            <button type="submit" class="btn">Salvează</button>
            <a href="afiseaza_componente.php" class="btn cancel">Anulează</a>
        </form>
    </div>
</main>

<footer>
    <p>&copy; 2025 Gestionare Componente</p>
</footer>
</body>
</html>
