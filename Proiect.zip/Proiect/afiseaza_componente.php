<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "proiectbd";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexiunea a eșuat: " . $conn->connect_error);
}

// Ștergere componentă
if (isset($_GET['sterge'])) {
    $id = intval($_GET['sterge']);
    $conn->query("DELETE FROM componente WHERE id_componente = $id");
    header("Location: afiseaza_componente.php");
    exit();
}

$result = $conn->query("SELECT id_componente, nume, categorie, cantitate FROM componente");
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Componente</title>
    <link rel="stylesheet" href="style6.css">
</head>
<body>

<header>
    <div class="container">
        <h1>Gestionare Componente</h1>
        <nav>
            <ul>
                <li><a href="index.php">Pagina Principală</a></li>
                <li><a href="adauga_componente.php">Adaugă Componentă</a></li>
                <li><a href="afiseaza_componente.php" class="active">Vezi Componente</a></li>
                <li><a href="adauga_asociere.php">Asociază Componență</a></li>
                <li><a href="adauga_comenzi.php">Adaugă Comandă</a></li>
                <li><a href="afiseaza_comenzi.php">Vezi Comenzi</a></li>
            </ul>
        </nav>
    </div>
</header>

<main>
    <div class="container">
        <h2>Componente Existente</h2>

        <div class="componente-list">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="component-card">
                    <h3><?= htmlspecialchars($row['nume']) ?></h3>
                    <p><strong>Categorie:</strong> <?= htmlspecialchars($row['categorie']) ?></p>
                    <p><strong>Cantitate:</strong> <?= htmlspecialchars($row['cantitate']) ?></p>
                    <div class="actions">
                        <a href="editeaza_componente.php?id=<?= $row['id_componente'] ?>" class="btn edit">Editează</a>
                        <a href="afiseaza_componente.php?sterge=<?= $row['id_componente'] ?>" class="btn delete" onclick="return confirm('Ești sigur că vrei să ștergi această componentă?')">Șterge</a>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</main>

<footer>
    <div class="container">
        <p>&copy; 2025 Gestionare Componente. Toate drepturile rezervate.</p>
    </div>
</footer>

</body>
</html>
