<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "proiectbd";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexiunea a eșuat: " . $conn->connect_error);
}

$q = isset($_GET['q']) ? $conn->real_escape_string($_GET['q']) : '';

$sql = "SELECT id_componente, nume FROM Componente WHERE nume LIKE '%$q%' ORDER BY nume ASC LIMIT 20";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<li><a href='afiseaza_componente.php?id_componente=" . $row["id_componente"] . "'>" . htmlspecialchars($row["nume"]) . "</a></li>";
    }
} else {
    echo "<li>Nu s-au găsit rezultate.</li>";
}
?>
